-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 17-02-2021 a las 14:46:29
-- Versión del servidor: 5.7.31
-- Versión de PHP: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `trueque_activo`
--
CREATE DATABASE IF NOT EXISTS `trueque_activo` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `trueque_activo`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_producto`
--

DROP TABLE IF EXISTS `estado_producto`;
CREATE TABLE IF NOT EXISTS `estado_producto` (
  `idestado` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_de_estado` varchar(30) NOT NULL,
  PRIMARY KEY (`idestado`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gestion_producto`
--

DROP TABLE IF EXISTS `gestion_producto`;
CREATE TABLE IF NOT EXISTS `gestion_producto` (
  `id_producto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_producto` varchar(20) NOT NULL,
  `descripcion` varchar(45) NOT NULL,
  `idestado` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `idtipo_producto` int(11) NOT NULL,
  PRIMARY KEY (`id_producto`),
  UNIQUE KEY `idestado` (`idestado`,`id_usuario`,`idtipo_producto`),
  KEY `id_usuario` (`id_usuario`),
  KEY `idtipo_producto` (`idtipo_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `intercambio`
--

DROP TABLE IF EXISTS `intercambio`;
CREATE TABLE IF NOT EXISTS `intercambio` (
  `idIntercambio` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `idtramite` int(11) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`idIntercambio`),
  UNIQUE KEY `id_usuario` (`id_usuario`,`idtramite`),
  UNIQUE KEY `id_usuario_2` (`id_usuario`,`idtramite`),
  KEY `idtramite` (`idtramite`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_producto`
--

DROP TABLE IF EXISTS `tipo_producto`;
CREATE TABLE IF NOT EXISTS `tipo_producto` (
  `idtipo_producto` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_producto` varchar(20) NOT NULL,
  PRIMARY KEY (`idtipo_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_usuario`
--

DROP TABLE IF EXISTS `tipo_usuario`;
CREATE TABLE IF NOT EXISTS `tipo_usuario` (
  `idtipo_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_usuario` varchar(20) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`idtipo_usuario`),
  UNIQUE KEY `id_usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tramite`
--

DROP TABLE IF EXISTS `tramite`;
CREATE TABLE IF NOT EXISTS `tramite` (
  `idtramite` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_tramite` varchar(15) NOT NULL,
  PRIMARY KEY (`idtramite`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(20) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `correo` varchar(40) NOT NULL,
  `password` varchar(150) NOT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nombre_usuario`, `apellido`, `telefono`, `correo`, `password`) VALUES
(1, 'camilo', 'muÃ±oz', '122', 'julian@gmail.com', '$2y$05$xMlDfR100Te29v7TrxOPF.XgFHGguLxZWB0PkFdwGWOpEq6vDtZge');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `gestion_producto`
--
ALTER TABLE `gestion_producto`
  ADD CONSTRAINT `gestion_producto_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`),
  ADD CONSTRAINT `gestion_producto_ibfk_2` FOREIGN KEY (`idtipo_producto`) REFERENCES `tipo_producto` (`idtipo_producto`),
  ADD CONSTRAINT `gestion_producto_ibfk_3` FOREIGN KEY (`idestado`) REFERENCES `estado_producto` (`idestado`);

--
-- Filtros para la tabla `intercambio`
--
ALTER TABLE `intercambio`
  ADD CONSTRAINT `intercambio_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`),
  ADD CONSTRAINT `intercambio_ibfk_2` FOREIGN KEY (`idtramite`) REFERENCES `tramite` (`idtramite`),
  ADD CONSTRAINT `intercambio_ibfk_3` FOREIGN KEY (`idIntercambio`) REFERENCES `tipo_producto` (`idtipo_producto`);

--
-- Filtros para la tabla `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  ADD CONSTRAINT `tipo_usuario_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
